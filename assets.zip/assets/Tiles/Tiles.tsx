<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Untitled design (4)" tilewidth="180" tileheight="180" tilecount="36" columns="6">
 <image source="../Tiled/Untitled design (4).png" width="1080" height="1080"/>
</tileset>
