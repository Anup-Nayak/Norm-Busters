<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="1f" tilewidth="180" tileheight="180" tilecount="36" columns="6">
 <image source="../Exit/Door1/1f.png" width="1080" height="1080"/>
</tileset>
