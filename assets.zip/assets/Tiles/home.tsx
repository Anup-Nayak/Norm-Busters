<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="home" tilewidth="180" tileheight="180" tilecount="24" columns="4">
 <image source="../home/home2.png" width="720" height="1080"/>
</tileset>
