<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Run2F" tilewidth="270" tileheight="384" tilecount="1" columns="1">
 <grid orientation="orthogonal" width="270" height="348"/>
 <image source="../Player/Run4F.png" width="270" height="384"/>
</tileset>
